<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Welcome')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <style>
        .categories {
            text-align: right;
            margin: 20px;
        }
        .content {
            text-align: center;
            margin: 20px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            justify-items: center;
        }
        .card {
            display: flex;
            align-items: stretch;
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            width: 300px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-right: 25px;
            margin-top: 25px;
        }

        .card img {
            width: 120px;
            height: 100%;
            object-fit: cover;
            flex-shrink: 0;
        }

        .card-body {
            padding: 10px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            flex-grow: 1;
        }

        .card-title {
            font-size: 18px;
            margin: 0 0 10px 0;
            
        }

        .card-text {
            font-size: 14px;
        }

        .pagination {
            text-align: center;
            margin: 20px;
        }
    </style>

    <div class="container">
        <div class="categories">
            <div class="dropdown">
                <button class="btn btn-danger dropdown-toggle" type="button" id="categoriesDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    Categories
                </button>
                <ul class="dropdown-menu" aria-labelledby="categoriesDropdown">
                    <li><a class="dropdown-item" href="<?php echo e(route('home')); ?>">All Categories</a></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('category.books', $category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="content">
            <p class="h2 text-left">Technology always update, upgrade your skill now</p>
            <p class="h4 text-left">The Newest technology</p>
            <div class="grid">
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <a href="<?php echo e(route('books.showDetail', $book->id)); ?>" class="d-flex">
                        <img src="<?php echo e($book->cover_url); ?>" alt="Book Cover">
                        <div class="card-body text-left">
                            <h5 class="card-title"><?php echo e($book->title); ?></h5>
                            <p class="card-text">Author: <?php echo e($book->author_name); ?></p>
                            <p class="card-text">Category: <?php echo e($book->category->name); ?></p>
                            <p class="card-text">Published Date: <?php echo e(\Carbon\Carbon::parse($book->published_date)->format('Y')); ?></p>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pagination">
                <?php echo e($books->links()); ?>

            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Semester 2 Year 3 Doc\web and cloud development\techbook-web(2)\techbook-web\resources\views/dashboard.blade.php ENDPATH**/ ?>