<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mt-4">
        <h2>Dashboard</h2>

        <div class="row">
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-header">New Book Requests</div>
                    <div class="card-body">
                        <p>Total Requests: <?php echo e($totalNewBookRequests); ?></p>
                        <p>Pending Requests: <?php echo e($pendingNewBookRequests); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-header">Feedback</div>
                    <div class="card-body">
                        <p>Total Feedbacks: <?php echo e($totalFeedbacks); ?></p>
                        <p>Pending Feedbacks: <?php echo e($pendingFeedbacks); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-header">Users</div>
                    <div class="card-body">
                        <p>Total Users: <?php echo e($totalUsers); ?></p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-header">Total Books</div>
                    <div class="card-body">
                        <p>Total Books: <?php echo e($totalBooks); ?></p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-4 p-3">
                <div class="card">
                    <div class="card-header">Total Categories</div>
                    <div class="card-body">
                        <p>Total Categories: <?php echo e($totalCategories); ?></p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH D:\AY2S2ITE2023\WCT_Final_Project\techbook\techbook-web(2)\techbook-web\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>