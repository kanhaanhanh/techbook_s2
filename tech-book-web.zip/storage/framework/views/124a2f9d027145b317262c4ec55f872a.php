<!-- resources/views/books/show.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TechBook</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/detailBook.css')); ?>">
</head>
<body>
    <style>
        li {
            margin-top: 10px;
        }
        .container {
            position: relative;
        }
        .action-buttons {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
        }
        .action-buttons button {
            margin-left: 3px;
            padding: 10px;
            width: 100px;
            height: 70px;
        }
        .book-cover {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 10px;
        }
        .feedback-section {
            margin-top: 20px;
        }
        .feedback-section h3 {
            margin-bottom: 15px;
        }
        .feedback-section .feedback {
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        .feedback-section .feedback p {
            margin: 0;
        }
    </style>
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Welcome')); ?>

            </h2>
         <?php $__env->endSlot(); ?>
        <div class="container p-6">
            <div class="row book-details">
                <div class="col-md-4">
                    <img src="<?php echo e($book->cover_url); ?>" alt="Book Cover" class="book-cover">
                </div>
                <div class="col-md-8 p-4 mb-4">
                    <p class="h3"><?php echo e($book->title); ?> - <small><?php echo e($book->author_name); ?></small></p>
                    <ul>
                        <li><strong>Category:</strong> <?php echo e($book->category->name); ?></li>
                        <li><strong>Publish Date:</strong> <?php echo e(\Carbon\Carbon::parse($book->published_date)->format('d M Y')); ?></li>
                        <li><strong>ISBN:</strong> <?php echo e($book->ISBN); ?></li>
                        <li><strong>Type:</strong> <?php echo e($book->type); ?></li>
                        <li><strong>Price:</strong> $<?php echo e($book->price); ?></li>
                    </ul>
                    <div class="action-buttons">
                        <?php if($book->type === 'Paid'): ?>
                            <form action="<?php echo e(route('cart.add', ['id' => $book->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">
                                    Add to Cart
                                </button>
                            </form>
                        <?php else: ?>
                            <button class="btn btn-primary" onclick="showDetails('<?php echo e($book->book_url); ?>')">
                                Read Book
                            </button>
                        <?php endif; ?>
                        <form action="<?php echo e(route('favorite.add', ['id' => $book->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">
                                Save to Favorite
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Feedback Section -->
            <div class="row feedback-section">
                <div class="col-md-12">
                    <h3>Leave Feedback</h3>
                    <form action="<?php echo e(route('feedback.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                        <textarea placeholder="Write your feedback about this book..." name="content" class="form-control"></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <button type="submit" class="btn btn-primary mt-2">Submit Feedback</button>
                    </form>
                </div>
            </div>

            <!-- Display Feedback -->
            <div class="row feedback-section">
                <div class="col-md-12">
                    <h3>Feedback</h3>
                    <?php $__currentLoopData = $book->feedbacks->whereIn('status', ['pending', 'approved']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="feedback">
                            <p><strong><?php echo e($feedback->user->name); ?></strong>
                                <?php if($feedback->created_at): ?>
                                    (<?php echo e($feedback->created_at->format('d M Y')); ?>):
                                <?php else: ?>
                                    (Date not available):
                                <?php endif; ?>
                            </p>
                            <p><?php echo e($feedback->content); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
    
    <script>
        function showDetails(book_url){
            window.location.href = "<?php echo e(route('pdf.viewer')); ?>?url=" + encodeURIComponent(book_url);
        }
    </script>
</body>
</html>
<?php /**PATH D:\Semester 2 Year 3 Doc\web and cloud development\techbook-web(2)\techbook-web\resources\views/detailBook.blade.php ENDPATH**/ ?>