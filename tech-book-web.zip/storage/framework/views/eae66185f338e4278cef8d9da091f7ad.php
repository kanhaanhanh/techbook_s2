<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mt-4">
        <h2>Edit Book Request</h2>
        
        <?php if(!isset($request->url)): ?>
        <form action="<?php echo e(route('book_requests.update', $request)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="book_title">Book Title/URL :</label>
                <input type="text" class="form-control" name="book_title" value="<?php echo e($request->book_title ?? $request->url); ?>" required>
            </div>
            <div class="form-group">
                <label for="author_name">Author Name:</label>
                <input type="text" class="form-control" name="author_name" value="<?php echo e($request->author_name); ?>" >
            </div>
            <div class="form-group">
                <label for="publish_date">Publish Date:</label>
                <input type="date" class="form-control" name="publish_date" value="<?php echo e($request->publish_date); ?>">
            </div>
            <div class="form-group">
                <label for="reason">Reason:</label>
                <textarea class="form-control" name="reason"><?php echo e($request->reason); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Request</button>
            <a href="<?php echo e(route('book_requests.index')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
        <?php else: ?>
        <form action="<?php echo e(route('book_requests.update', $request)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="url">URL:</label>
                <input type="url" class="form-control" name="url" value="<?php echo e($request->url); ?>" required>
            </div>
            <div class="form-group">
                <label for="reason">Reason:</label>
                <textarea class="form-control" name="reason"><?php echo e($request->reason); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update Request</button>
            <a href="<?php echo e(route('book_requests.index')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Semester 2 Year 3 Doc\web and cloud development\techbook-web(2)\techbook-web\resources\views/edit_request_books.blade.php ENDPATH**/ ?>