<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Shopping Cart')); ?>

        </h2>
        <style>
            .button {
                display: inline-block;
                margin-top: 20px;
                padding: 10px 20px;
                background-color: blue;
                color: white;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                font-weight: bold;
                text-decoration: none;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            .button:hover {
                background-color: #0056b3; /* Darker shade of blue on hover */
            }
        </style>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4 py-8">
        <?php if($cart->count() > 0): ?>
            <div class="flex flex-wrap justify-start -mx-4">
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full md:w-1/2 lg:w-1/3 px-4 mb-8">
                        <div class="bg-white rounded-lg shadow-md overflow-hidden flex flex-col h-full">
                            <div class="p-4 flex-grow">
                                <h3 class="text-lg font-semibold text-gray-800 mb-2"><?php echo e($item['title']); ?></h3>
                                <p class="text-gray-600 mb-2">Price: $<?php echo e($item['price']); ?></p>
                            </div>
                            <div class="bg-gray-100 px-4 py-2 flex justify-end space-x-4">
                                <form action="<?php echo e(route('cart.remove', ['id' => $item['id']])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-700 font-semibold">Remove</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="mt-8 text-center">
                <p class="text-lg font-semibold">Total Price: $<?php echo e($totalPrice); ?></p>
                <a href="<?php echo e(route('checkout.show')); ?>" class="button">Proceed to Checkout</a>
            </div>
        <?php else: ?>
            <div class="text-center">
                <p class="text-gray-600 text-lg">Your cart is empty.</p>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\AY2S2ITE2023\WCT_Final_Project\techbook\techbook-web(2)\techbook-web\resources\views/cart/show.blade.php ENDPATH**/ ?>