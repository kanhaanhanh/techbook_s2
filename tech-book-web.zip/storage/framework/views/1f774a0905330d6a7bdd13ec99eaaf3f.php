<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="inline-flex items-center justify-center w-6 h-6 overflow-hidden rounded-full <?php echo e($user->avatar ? 'bg-transparent' : 'bg-light-green'); ?>">
  <?php if($user->avatar): ?>
    <img src="<?php echo e(asset('storage/avatars/' . $user->avatar)); ?>" alt="Avatar" class="w-10 h-10 object-fit: cover">
  <?php else: ?>
    <span class="text-base font-semibold text-white flex items-center justify-center"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
  <?php endif; ?>
</div>
<?php /**PATH D:\AY2S2ITE2023\WCT_Final_Project\techbook-web\resources\views/components/avatar.blade.php ENDPATH**/ ?>