<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body>
<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mt-5">
        <?php if(Session::has('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(Session::get('error')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>

        <h2>Edit Book</h2>
        <form id="editBookForm" method="POST" action="/admin/books/update/<?php echo e($book->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="ISBN" class="form-label">ISBN</label>
                <input type="text" class="form-control" name="ISBN" id="ISBN" placeholder="ISBN"
                    value="<?php echo e($book->ISBN); ?>">
            </div>
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" name="title" id="title" placeholder="Title"
                    value="<?php echo e($book->title); ?>">
            </div>
            <div class="mb-3">
                <label for="category" class="form-label">Category</label>
                <select class="form-select" name="category" id="category">
                    <option value="" selected disabled>Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"
                        <?php echo e($category->id == $book->category_id ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="author_name" class="form-label">Author Name</label>
                <input type="text" class="form-control" name="author_name" id="author_name"
                    placeholder="Author Name" value="<?php echo e($book->author_name); ?>">
            </div>
            <div class="mb-3">
                <label for="published_date" class="form-label">Published Date</label>
                <input type="date" class="form-control" name="published_date" id="published_date"
                    value="<?php echo e($book->published_date); ?>">
            </div>
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="number" class="form-control" name="price" id="price" placeholder="$"
                    value="<?php echo e($book->price); ?>">
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <select class="form-select" name="status" id="status">
                    <option value="Approved" <?php echo e($book->status == 'Approved' ? 'selected' : ''); ?>>Approved</option>
                    <option value="Denied" <?php echo e($book->status == 'Denied' ? 'selected' : ''); ?>>Denied</option>
                    <option value="Pending" <?php echo e($book->status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" name="type" id="type">
                    <option value="Free" <?php echo e($book->type == 'Free' ? 'selected' : ''); ?>>Free</option>
                    <option value="Paid" <?php echo e($book->type == 'Paid' ? 'selected' : ''); ?>>Paid</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="cover_image" class="form-label">Cover Image</label>
                <input type="file" class="form-control" name="cover_image" id="cover_image">
            </div>
            <div class="mb-3">
                <label for="book_file" class="form-label">Book File (PDF)</label>
                <input type="file" class="form-control" name="book_file" id="book_file">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <a href="/admin/books" class="btn btn-secondary mt-3">Back to Books</a>
    </div>

    
    <script>
        // You can include JavaScript validation here if needed
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\AY2S2ITE2023\WCT_Final_Project\techbook\techbook-web(2)\techbook-web\resources\views/admin/editBook.blade.php ENDPATH**/ ?>